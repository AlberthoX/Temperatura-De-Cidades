const tempAtual = document.querySelector("#tempAtual");
const sensTermica = document.querySelector("#sensTermica");
const tempMaxima = document.querySelector("#tempMaxima");
const tempMinima = document.querySelector("#tempMinima");
const btnEnviar = document.querySelector("#btnEnviar");
const textEntrada = document.querySelector("#textEntrada");


btnEnviar.addEventListener("click", (event) => {
    dadosAPI();
})

function dadosAPI(){
    const url = "https://api.openweathermap.org/data/2.5/weather?q=" + textEntrada.value + "&appid=49ed513a0189f9e469893c1510528137&units=metric"
    const request = new XMLHttpRequest();
    request.open("GET", url);
    request.send();
    request.onload = ()=>{
        let resposta = JSON.parse(request.response);
        tempAtual.innerHTML = "Temperatura Atual:" + resposta.main.temp + "°C"
        sensTermica.innerHTML = "Sensação Termica:" + resposta.main.temp + "°C"
        tempMaxima.innerHTML = "Temperatura Maxima:" + resposta.main.temp + "°C"
        tempMinima.innerHTML = "Temperatura Minima" + resposta.main.temp + "°C"
    }
}
